# Caskan データモデル定義書（Lovable実装向け）

本ドキュメントは、Caskanの管理画面から読み取れるデータ構造を、Lovableでの実装に活用できる形式で整理したものです。

## 1. エンティティ一覧

| エンティティ名 | 説明 | 推定レコード規模 |
|:---|:---|:---|
| Shop | 店舗情報 | 1（テナント単位） |
| Staff | 管理スタッフ | 数名 |
| Cast | キャスト（セラピスト） | 数十名 |
| Customer | 顧客 | 数百〜数千 |
| Reservation | 予約 | 数千〜数万 |
| Shift | シフト | 数百/月 |
| Course | コース | 数件 |
| CoursePlan | コース料金プラン | 数十件 |
| Option | オプション | 数件〜十数件 |
| Discount | 割引 | 数件 |
| Room | ルーム（施術部屋） | 数件 |
| Area | エリア | 数件 |
| Expense | 経費 | 数十/月 |
| Article | 記事（お知らせ） | 数十件 |
| Bill | 請求（Caskan利用料） | 月1件 |

## 2. 各エンティティの詳細フィールド定義

### 2.1. Shop（店舗）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | string | Yes | 店舗ID（例: Zenryoku1209） |
| name | string | Yes | 店舗名 |
| catchphrase | string | No | キャッチコピー |
| hp_url | string | No | ホームページURL |
| description | text | No | 店舗紹介 |
| phone | string | No | 店舗電話番号 |
| business_hours | string | No | 営業時間 |
| nearest_station | string | No | 最寄り駅 |
| email | string | No | メールアドレス |
| status | enum | Yes | ステータス（稼働中, 停止中） |
| plan | string | No | 契約プラン |
| web_reserve_enabled | boolean | Yes | Web予約の有効/無効 |
| min_lead_time | integer | No | 最短案内時間（分） |
| interval | integer | No | インターバル（分） |
| booking_interval | integer | No | 受付間隔（分） |
| same_day_booking | boolean | Yes | 当日予約の可否 |
| free_booking | boolean | Yes | フリー予約の使用可否 |
| line_webhook_url | string | No | LINE Webhook URL |
| line_secret | string | No | LINEシークレットキー |
| line_access_token | string | No | LINEアクセストークン |
| line_notification | boolean | No | LINE通知の有効/無効 |
| twilio_account_id | string | No | TwilioアカウントID |
| twilio_token | string | No | Twilioトークン |
| twilio_phone | string | No | Twilio電話番号 |

### 2.2. Staff（スタッフ）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | スタッフID |
| name | string | Yes | 名前 |
| login_id | string | Yes | ログインID |
| password | string | Yes | パスワード（ハッシュ） |
| status | enum | Yes | ステータス（稼働中, 停止中） |
| last_login | datetime | No | 最終ログイン日時 |

### 2.3. Cast（キャスト）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | キャストID |
| name | string | Yes | 名前 |
| name_kana | string | No | よみ |
| introduction | string | No | ひと言紹介 |
| age | integer | No | 年齢 |
| height | integer | No | 身長（cm） |
| cup | string | No | カップ |
| bust | integer | No | バスト |
| waist | integer | No | ウエスト |
| hip | integer | No | ヒップ |
| labels | text | No | ラベル（改行区切り） |
| is_new | boolean | No | 新人セラピストフラグ |
| is_pickup | boolean | No | ピックアップフラグ |
| shop_comment | text | No | お店コメント |
| message | text | No | メッセージ |
| widget | text | No | ウィジェット |
| sns_url | string | No | SNS URL |
| bluesky_id | string | No | Bluesky ID |
| internal_memo | text | No | 内部メモ |
| shift_memo | text | No | シフトメモ |
| status | enum | Yes | ステータス（未掲載, 掲載中, 退店） |
| course_back_rate | decimal | No | コースバック率（%） |
| photo_nomination_fee | integer | No | 写真指名料（円） |
| photo_nomination_reward | integer | No | 写真指名報酬（円） |
| main_nomination_fee | integer | No | 本指名料（円） |
| main_nomination_reward | integer | No | 本指名報酬（円） |
| hime_fee | integer | No | 姫予約料（円） |
| hime_reward | integer | No | 姫予約報酬（円） |
| margin_rate | decimal | No | マージン率（%） |
| interval | enum | No | インターバル（全体設定/5/10/15/20分） |
| login_id | string | No | ログインID |
| password | string | No | パスワード |
| permission_reservation | enum | No | 予約情報権限（閲覧のみ/制限付き/すべて） |
| permission_shift_edit | boolean | No | シフト編集権限 |
| permission_all_shift | boolean | No | 全体シフト閲覧権限 |
| email | string | No | メールアドレス |
| sort_order | integer | No | 表示順 |
| images | file[] | No | プロフィール画像（複数、600x800px） |

### 2.4. Customer（顧客）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | 顧客ID |
| name | string | Yes | 名前 |
| name_kana | string | No | フリガナ |
| phone | string | No | 電話番号 |
| email | string | No | メールアドレス |
| shop_memo | text | No | 店舗用メモ |
| cast_memo | text | No | キャスト用メモ |
| status | enum | Yes | ステータス（良好, 要注意, 出禁） |
| is_foreigner | boolean | No | 外国人フラグ |
| visit_count | integer | No | 利用回数（自動集計） |
| created_at | datetime | Yes | 登録日時 |

### 2.5. Reservation（予約）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | 予約ID |
| customer_id | integer (FK) | No | 顧客ID |
| customer_name | string | No | 予約名 |
| customer_kana | string | No | フリガナ |
| customer_phone | string | No | 電話番号 |
| customer_email | string | No | メールアドレス |
| cast_id | integer (FK) | No | 担当キャストID |
| nomination_type | enum | No | 指名種別（なし, 写真指名, 本指名） |
| course_plan_id | integer (FK) | No | コースプランID |
| start_datetime | datetime | Yes | 開始日時 |
| end_datetime | datetime | Yes | 終了日時 |
| room_id | integer (FK) | No | ルームID |
| request_memo | text | No | 予約時ご要望 |
| payment_method | enum | No | 支払方法（現金, カード, PayPay） |
| dispatch_area | string | No | 派遣エリア |
| treatment_memo | text | No | 施術メモ |
| booking_method | enum | No | 予約方法（電話, WEB, LINE, SMS, Twitter, 姫予約, その他） |
| ad_source_id | integer (FK) | No | 広告媒体ID |
| ad_source_other | string | No | その他の広告 |
| status | enum | Yes | ステータス（新規予約, 調整中, 予約確定, 完了, キャンセル, 下書き） |
| registered_by | integer (FK) | No | 登録担当スタッフID |
| cast_edit_allowed | boolean | No | キャスト編集許可 |
| shop_course_fee | integer | No | コース料金（店舗） |
| cast_course_fee | integer | No | コース料金（キャスト） |
| shop_option_fee | integer | No | オプション料金（店舗） |
| cast_option_fee | integer | No | オプション料金（キャスト） |
| shop_nomination_fee | integer | No | 指名料（店舗） |
| cast_nomination_fee | integer | No | 指名料（キャスト） |
| shop_discount | integer | No | 割引（店舗） |
| cast_discount | integer | No | 割引（キャスト） |
| manual_discount | integer | No | 手動割引 |
| transportation_fee | integer | No | 交通費 |
| settlement_fee | integer | No | 決済手数料 |
| shop_other_fee | integer | No | その他（店舗） |
| cast_other_fee | integer | No | その他（キャスト） |
| payment_cash | integer | No | 現金決済額 |
| payment_card | integer | No | カード決済額 |
| payment_electronic | integer | No | 電子決済額 |
| created_at | datetime | Yes | 登録日時 |

### 2.6. ReservationOption（予約-オプション中間テーブル）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| reservation_id | integer (FK) | Yes | 予約ID |
| option_id | integer (FK) | Yes | オプションID |

### 2.7. ReservationDiscount（予約-割引中間テーブル）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| reservation_id | integer (FK) | Yes | 予約ID |
| discount_id | integer (FK) | Yes | 割引ID |

### 2.8. Shift（シフト）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | シフトID |
| cast_id | integer (FK) | Yes | キャストID |
| date | date | Yes | 日付 |
| start_time | time | No | 出勤時間 |
| end_time | time | No | 退勤時間 |
| time_undecided | boolean | No | 時間未定フラグ |
| room_id | integer (FK) | No | ルームID |
| memo | text | No | メモ |
| status | enum | Yes | ステータス（未承認, 承認済み） |

### 2.9. Course（コース）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | コースID |
| name | string | Yes | コース名 |
| description | text | No | 説明文 |
| is_public | boolean | Yes | 公開/非公開 |
| sort_order | integer | No | 表示順 |

### 2.10. CoursePlan（コース料金プラン）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | プランID |
| course_id | integer (FK) | Yes | コースID |
| display_name | string | Yes | 表示名（例: 80分） |
| price | integer | Yes | 料金（円） |
| list_price | integer | No | 定価（円） |
| duration | integer | Yes | 所要時間（分） |
| reward | integer | No | キャスト報酬（円） |

### 2.11. Option（オプション）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | オプションID |
| name | string | Yes | 項目名 |
| price | integer | Yes | 料金（円） |
| price_display | string | No | 料金表記 |
| is_extension | boolean | No | 延長フラグ |
| is_visible | boolean | Yes | 表示/非表示 |
| show_on_form | boolean | No | フォーム表示 |
| reward_type | enum | No | 報酬設定（セラピスト/固定バック） |
| reward | integer | No | 報酬額（円） |
| sort_order | integer | No | 表示順 |

### 2.12. Discount（割引）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | 割引ID |
| name | string | Yes | 割引名 |
| original_price | integer | No | 元の価格（円） |
| discounted_price | integer | No | 割引後価格（円） |
| sort_order | integer | No | 表示順 |

### 2.13. Room（ルーム）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | ルームID |
| name | string | Yes | ルーム名 |
| display_name | string | No | 表示名 |
| area_id | integer (FK) | No | エリアID |
| email_text | text | No | メールテキスト |
| sms_text | text | No | SMSテキスト |
| cast_guide | text | No | キャスト用案内 |
| internal_memo | text | No | 内部メモ |
| is_visible_hp | boolean | Yes | HP表示（表示/非表示） |
| access | text | No | アクセス情報 |
| map_address | string | No | Map住所 |
| image | file | No | 画像 |
| sort_order | integer | No | 表示順 |

### 2.14. Area（エリア）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | エリアID |
| name | string | Yes | エリア名 |

### 2.15. Expense（経費）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | 経費ID |
| date | date | Yes | 日付 |
| category | enum | Yes | 項目（雑費, 宿泊費, 交通費, 負担分, 一本目割引） |
| amount | integer | Yes | 金額（円） |
| cast_id | integer (FK) | No | キャストID |
| memo | text | No | メモ |

### 2.16. Article（記事）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | 記事ID |
| title | string | Yes | タイトル |
| content | text | Yes | 本文 |
| status | enum | Yes | ステータス（公開, 非公開） |
| published_at | datetime | No | 公開日時 |

### 2.17. AdSource（広告媒体）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| id | integer | Yes | 媒体ID |
| name | string | Yes | 媒体名 |

**登録されている広告媒体一覧**: メンズエステランキング, エステ魂, メンズエステマガジン, 週刊エステ, アロマパンダ, シティヘブン, 駅ちか, 口コミ風俗情報局, X（旧Twitter）, TikTok, Instagram, GoogleMap, 店舗HP, 看板, 知人の紹介, エステクイーン, エステアイ, エスナビ, ME（メンエス）

### 2.18. CastNgCourse / CastNgOption（キャスト-NGコース/オプション中間テーブル）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| cast_id | integer (FK) | Yes | キャストID |
| course_id / option_id | integer (FK) | Yes | コースID / オプションID |

### 2.19. CustomerNgCast / CustomerFavCast（顧客-NGキャスト/指名キャスト中間テーブル）

| フィールド名 | 型 | 必須 | 説明 |
|:---|:---|:---:|:---|
| customer_id | integer (FK) | Yes | 顧客ID |
| cast_id | integer (FK) | Yes | キャストID |

## 3. ER図（テキスト表現）

```
Shop (1) ──── (N) Staff
Shop (1) ──── (N) Cast
Shop (1) ──── (N) Customer
Shop (1) ──── (N) Room
Shop (1) ──── (N) Area
Shop (1) ──── (N) Course
Shop (1) ──── (N) Option
Shop (1) ──── (N) Discount
Shop (1) ──── (N) AdSource

Course (1) ──── (N) CoursePlan
Area (1) ──── (N) Room

Cast (1) ──── (N) Shift
Cast (1) ──── (N) Reservation
Customer (1) ──── (N) Reservation
Room (1) ──── (N) Reservation
Room (1) ──── (N) Shift
CoursePlan (1) ──── (N) Reservation

Reservation (N) ──── (N) Option   [via ReservationOption]
Reservation (N) ──── (N) Discount [via ReservationDiscount]

Cast (N) ──── (N) Course  [via CastNgCourse]
Cast (N) ──── (N) Option  [via CastNgOption]

Customer (N) ──── (N) Cast [via CustomerNgCast]
Customer (N) ──── (N) Cast [via CustomerFavCast]

Cast (1) ──── (N) Expense
```

## 4. 画面遷移マップ

```
ホーム (/)
├── スケジュール (/schedule)
│   ├── タイムチャート (/schedule)
│   └── 週カレンダー (/schedule/week)
├── シフト (/shift)
│   ├── シフト登録 (/shift)
│   └── シフト表 (/shift/view)
├── 予約 (/reserve)
│   └── 予約登録/編集 (/reserve/edit?id=xxx)
├── 顧客 (/customer)
│   └── 顧客詳細 (/customer/view?id=xxx)
│       ├── 基本情報タブ
│       ├── 来店履歴タブ
│       └── 画像タブ
│       └── 顧客編集 (/customer/edit?id=xxx)
├── キャスト (/cast)
│   ├── 在籍タブ
│   ├── 退店済みタブ
│   └── 削除済みタブ
│   └── キャスト編集 (/cast/edit?id=xxx)
├── 料金システム (/system/edit)
├── ルーム (/room)
│   ├── ルームタブ
│   └── エリアタブ (/area)
│   └── ルーム編集 (/room/edit/xxx)
├── 報酬 (/guarantee)
├── 経費 (/expense)
├── ホームページ (/design/edit)
│   ├── プレビュータブ
│   ├── 設定タブ
│   ├── 記事タブ (/article)
│   └── 求人ページタブ (/recruit/edit)
├── レポート (/report)
│   ├── 日別タブ
│   ├── 月別タブ
│   ├── キャスト別タブ
│   ├── ルーム別タブ
│   ├── 経路別タブ
│   └── 媒体別タブ
├── 設定 (/shop)
│   ├── 基本情報タブ
│   ├── 定型文タブ (/script)
│   └── スタッフタブ (/staff)
├── 請求 (/bill)
└── 公開HP (外部: zenryoku-esthe.com)
    └── Web予約フォーム (外部: r.caskan.jp/zenryoku1209)
```

## 5. Enum（列挙型）定義一覧

| Enum名 | 値 | 使用箇所 |
|:---|:---|:---|
| ReservationStatus | 新規予約(1), 調整中(5), 予約確定(10), 完了(20), キャンセル(99), 下書き(100) | Reservation.status |
| NominationType | 指名なし(0), 写真指名(1), 本指名(2) | Reservation.nomination_type |
| PaymentMethod | 現金(10), カード(20), PayPay(30) | Reservation.payment_method |
| BookingMethod | WEB(1), 電話(2), LINE(3), SMS(4), Twitter(5), 姫予約(6), その他(7) | Reservation.booking_method |
| CastStatus | 未掲載(0), 掲載中(1), 退店(-1) | Cast.status |
| CustomerStatus | 良好(1), 要注意(10), 出禁(99) | Customer.status |
| ShiftStatus | 未承認, 承認済み | Shift.status |
| CastPermissionReservation | 閲覧のみ(0), 制限付き編集(5), すべて編集(10) | Cast.permission_reservation |
| ExpenseCategory | 雑費, 宿泊費, 交通費, 負担分, 一本目割引 | Expense.category |
