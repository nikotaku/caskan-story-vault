
/**
 * Caskan Reservation Management System - Main JavaScript
 * Handles navigation, mobile menu, and core functionality
 */

// Global state management
const CaskanApp = {
    currentPage: 'dashboard',
    isMobile: false,
    sidebarOpen: false,

    // Initialize the application
    init() {
        this.detectMobile();
        this.setupEventListeners();
        this.setActivePage();
        this.setupMobileMenu();
        this.loadPageContent();

        // Add fade-in animation to content
        document.addEventListener('DOMContentLoaded', () => {
            const contentArea = document.querySelector('.content-area');
            if (contentArea) {
                contentArea.classList.add('fade-in');
            }
        });
    },

    // Detect mobile device
    detectMobile() {
        this.isMobile = window.innerWidth <= 767;

        window.addEventListener('resize', () => {
            const wasMobile = this.isMobile;
            this.isMobile = window.innerWidth <= 767;

            if (wasMobile !== this.isMobile) {
                this.handleResponsiveChanges();
            }
        });
    },

    // Handle responsive changes
    handleResponsiveChanges() {
        const sidebar = document.querySelector('.sidebar');
        const overlay = document.querySelector('.sidebar-overlay');

        if (!this.isMobile) {
            sidebar?.classList.remove('mobile-open');
            overlay?.classList.remove('show');
            this.sidebarOpen = false;
        }
    },

    // Setup mobile menu functionality
    setupMobileMenu() {
        const menuBtn = document.querySelector('.mobile-menu-btn');
        const sidebar = document.querySelector('.sidebar');
        const overlay = document.querySelector('.sidebar-overlay');

        if (menuBtn && sidebar && overlay) {
            // Mobile menu toggle
            menuBtn.addEventListener('click', () => {
                this.toggleMobileMenu();
            });

            // Close menu when clicking overlay
            overlay.addEventListener('click', () => {
                this.closeMobileMenu();
            });

            // Close menu when clicking nav links
            const navLinks = sidebar.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                link.addEventListener('click', () => {
                    if (this.isMobile) {
                        this.closeMobileMenu();
                    }
                });
            });
        }
    },

    // Toggle mobile menu
    toggleMobileMenu() {
        const sidebar = document.querySelector('.sidebar');
        const overlay = document.querySelector('.sidebar-overlay');

        this.sidebarOpen = !this.sidebarOpen;

        if (this.sidebarOpen) {
            sidebar?.classList.add('mobile-open');
            overlay?.classList.add('show');
        } else {
            sidebar?.classList.remove('mobile-open');
            overlay?.classList.remove('show');
        }
    },

    // Close mobile menu
    closeMobileMenu() {
        const sidebar = document.querySelector('.sidebar');
        const overlay = document.querySelector('.sidebar-overlay');

        sidebar?.classList.remove('mobile-open');
        overlay?.classList.remove('show');
        this.sidebarOpen = false;
    },

    // Setup event listeners
    setupEventListeners() {
        // Navigation links
        document.addEventListener('click', (e) => {
            if (e.target.matches('.nav-link')) {
                e.preventDefault();
                const page = e.target.getAttribute('data-page');
                if (page) {
                    this.navigateToPage(page);
                }
            }
        });

        // Form submissions
        document.addEventListener('submit', (e) => {
            if (e.target.matches('form')) {
                this.handleFormSubmit(e);
            }
        });

        // Button clicks
        document.addEventListener('click', (e) => {
            if (e.target.matches('.btn[data-action]')) {
                e.preventDefault();
                const action = e.target.getAttribute('data-action');
                this.handleAction(action, e.target);
            }
        });
    },

    // Navigate to different pages
    navigateToPage(page) {
        this.currentPage = page;
        this.setActivePage();
        this.loadPageContent();

        // Update page title
        const pageTitle = document.querySelector('.page-title');
        if (pageTitle) {
            pageTitle.textContent = this.getPageTitle(page);
        }

        // Update URL without page reload
        if (history.pushState) {
            const newUrl = page === 'dashboard' ? '/' : `/${page}.html`;
            history.pushState({page: page}, '', newUrl);
        }
    },

    // Set active navigation item
    setActivePage() {
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            const linkPage = link.getAttribute('data-page');
            if (linkPage === this.currentPage) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    },

    // Get page title based on page name
    getPageTitle(page) {
        const titles = {
            'dashboard': 'ダッシュボード',
            'schedule': 'スケジュール',
            'reservations': '予約管理',
            'reports': 'レポート',
            'customers': 'お客様管理',
            'staff': 'スタッフ管理',
            'settings': '設定'
        };
        return titles[page] || 'Caskan';
    },

    // Load page content (placeholder for future implementation)
    loadPageContent() {
        // This would typically load content via AJAX
        // For now, we'll just show a loading animation
        const contentArea = document.querySelector('.content-area');
        if (contentArea) {
            contentArea.style.opacity = '0.7';
            setTimeout(() => {
                contentArea.style.opacity = '1';
            }, 200);
        }
    },

    // Handle form submissions
    handleFormSubmit(e) {
        e.preventDefault();
        const form = e.target;
        const formData = new FormData(form);

        // Show loading state
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            const originalText = submitBtn.textContent;
            submitBtn.textContent = '処理中...';
            submitBtn.disabled = true;

            // Simulate form processing
            setTimeout(() => {
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
                this.showNotification('フォームが正常に送信されました', 'success');
            }, 1500);
        }
    },

    // Handle various actions
    handleAction(action, element) {
        switch (action) {
            case 'add-reservation':
                this.showModal('新規予約');
                break;
            case 'edit-reservation':
                const id = element.getAttribute('data-id');
                this.showModal('予約編集', id);
                break;
            case 'delete-reservation':
                this.confirmDelete('予約を削除しますか？');
                break;
            case 'export-data':
                this.exportData();
                break;
            case 'refresh-data':
                this.refreshData();
                break;
            default:
                console.log('Unknown action:', action);
        }
    },

    // Show modal dialog
    showModal(title, id = null) {
        // Create modal HTML
        const modalHTML = `
            <div class="modal-overlay">
                <div class="modal">
                    <div class="modal-header">
                        <h3>${title}</h3>
                        <button class="modal-close">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>モーダルコンテンツはここに表示されます</p>
                        ${id ? `<p>ID: ${id}</p>` : ''}
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary modal-close">キャンセル</button>
                        <button class="btn btn-primary">保存</button>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);

        // Setup modal event listeners
        const modal = document.querySelector('.modal-overlay');
        const closeButtons = modal.querySelectorAll('.modal-close');

        closeButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                modal.remove();
            });
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    },

    // Confirm delete action
    confirmDelete(message) {
        if (confirm(message)) {
            this.showNotification('削除しました', 'success');
        }
    },

    // Export data
    exportData() {
        this.showNotification('データをエクスポート中...', 'info');
        // Simulate export process
        setTimeout(() => {
            this.showNotification('データのエクスポートが完了しました', 'success');
        }, 2000);
    },

    // Refresh data
    refreshData() {
        this.showNotification('データを更新中...', 'info');
        // Simulate refresh process
        setTimeout(() => {
            this.showNotification('データが更新されました', 'success');
        }, 1000);
    },

    // Show notification
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;

        // Add notification styles
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
            color: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            animation: slideInRight 0.3s ease-out;
            max-width: 300px;
            word-wrap: break-word;
        `;

        document.body.appendChild(notification);

        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease-out';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    },

    // Utility function to format date
    formatDate(date) {
        const options = { 
            year: 'numeric', 
            month: '2-digit', 
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        };
        return new Intl.DateTimeFormat('ja-JP', options).format(date);
    },

    // Utility function to format currency
    formatCurrency(amount) {
        return new Intl.NumberFormat('ja-JP', {
            style: 'currency',
            currency: 'JPY'
        }).format(amount);
    }
};

// Animation keyframes (added via JavaScript)
const animationCSS = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }

    .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100vh;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
    }

    .modal {
        background: white;
        border-radius: 12px;
        max-width: 500px;
        width: 90%;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
    }

    .modal-header {
        padding: 1.5rem;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .modal-header h3 {
        margin: 0;
        color: #1e3a8a;
    }

    .modal-close {
        background: none;
        border: none;
        font-size: 1.5rem;
        cursor: pointer;
        color: #6b7280;
        padding: 0;
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .modal-body {
        padding: 1.5rem;
    }

    .modal-footer {
        padding: 1.5rem;
        border-top: 1px solid #e2e8f0;
        display: flex;
        gap: 1rem;
        justify-content: flex-end;
    }
`;

// Add animation styles to document
const styleSheet = document.createElement('style');
styleSheet.textContent = animationCSS;
document.head.appendChild(styleSheet);

// Initialize the application when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => CaskanApp.init());
} else {
    CaskanApp.init();
}

// Export for global access
window.CaskanApp = CaskanApp;
