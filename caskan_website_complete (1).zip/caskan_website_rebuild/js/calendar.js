
/**
 * Caskan Reservation Management System - Calendar JavaScript
 * Handles calendar functionality and appointment scheduling
 */

// Calendar management system
const CaskanCalendar = {
    // Calendar state
    currentDate: new Date(),
    selectedDate: null,
    events: [],
    view: 'month', // 'month', 'week', 'day'

    // Calendar configuration
    config: {
        timeSlots: {
            start: 9,  // 9 AM
            end: 22,   // 10 PM
            interval: 30 // 30 minutes
        },
        workingDays: [1, 2, 3, 4, 5, 6], // Monday to Saturday
        monthNames: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
        dayNames: ['日', '月', '火', '水', '木', '金', '土'],
        dayNamesShort: ['日', '月', '火', '水', '木', '金', '土']
    },

    // Initialize calendar
    init() {
        this.loadSampleEvents();
        this.renderCalendar();
        this.setupEventListeners();
        this.setupTimeSlots();
    },

    // Setup event listeners
    setupEventListeners() {
        // Navigation buttons
        document.addEventListener('click', (e) => {
            if (e.target.matches('.calendar-nav-prev')) {
                this.navigatePrevious();
            } else if (e.target.matches('.calendar-nav-next')) {
                this.navigateNext();
            } else if (e.target.matches('.calendar-nav-today')) {
                this.goToToday();
            } else if (e.target.matches('.calendar-view-btn')) {
                const view = e.target.getAttribute('data-view');
                this.changeView(view);
            } else if (e.target.matches('.calendar-day')) {
                const date = e.target.getAttribute('data-date');
                this.selectDate(new Date(date));
            } else if (e.target.matches('.time-slot')) {
                this.handleTimeSlotClick(e.target);
            }
        });

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.target.closest('.calendar-container')) {
                this.handleKeyboardNavigation(e);
            }
        });
    },

    // Load sample events for demonstration
    loadSampleEvents() {
        const today = new Date();
        const events = [
            {
                id: 1,
                title: '田中様 - アロマトリートメント',
                start: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 10, 0),
                end: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 11, 30),
                customer: '田中花子',
                service: 'アロマトリートメント',
                staff: '佐藤美香',
                status: 'confirmed',
                color: '#10b981'
            },
            {
                id: 2,
                title: '山田様 - タイ古式マッサージ',
                start: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 14, 0),
                end: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 15, 30),
                customer: '山田太郎',
                service: 'タイ古式マッサージ',
                staff: '鈴木恵美',
                status: 'confirmed',
                color: '#1e3a8a'
            },
            {
                id: 3,
                title: '佐藤様 - リフレクソロジー',
                start: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1, 11, 0),
                end: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1, 12, 0),
                customer: '佐藤一郎',
                service: 'リフレクソロジー',
                staff: '田中由美',
                status: 'tentative',
                color: '#f59e0b'
            }
        ];

        this.events = events;
    },

    // Render calendar based on current view
    renderCalendar() {
        const container = document.getElementById('calendar-container');
        if (!container) return;

        let calendarHTML = '';

        switch (this.view) {
            case 'month':
                calendarHTML = this.renderMonthView();
                break;
            case 'week':
                calendarHTML = this.renderWeekView();
                break;
            case 'day':
                calendarHTML = this.renderDayView();
                break;
        }

        container.innerHTML = calendarHTML;
        this.updateCalendarHeader();
    },

    // Render month view
    renderMonthView() {
        const year = this.currentDate.getFullYear();
        const month = this.currentDate.getMonth();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const startDate = new Date(firstDay);
        startDate.setDate(startDate.getDate() - firstDay.getDay());

        let html = `
            <div class="calendar-grid month-view">
                <div class="calendar-header">
        `;

        // Day headers
        this.config.dayNamesShort.forEach(day => {
            html += `<div class="day-header">${day}</div>`;
        });

        html += `</div><div class="calendar-body">`;

        // Calendar days
        const current = new Date(startDate);
        for (let week = 0; week < 6; week++) {
            for (let day = 0; day < 7; day++) {
                const isCurrentMonth = current.getMonth() === month;
                const isToday = this.isToday(current);
                const isSelected = this.selectedDate && this.isSameDay(current, this.selectedDate);
                const dayEvents = this.getEventsForDate(current);

                html += `
                    <div class="calendar-day ${isCurrentMonth ? 'current-month' : 'other-month'} 
                              ${isToday ? 'today' : ''} ${isSelected ? 'selected' : ''}"
                         data-date="${current.toISOString()}">
                        <div class="day-number">${current.getDate()}</div>
                        <div class="day-events">
                `;

                dayEvents.slice(0, 3).forEach(event => {
                    html += `
                        <div class="event-dot" 
                             style="background-color: ${event.color}"
                             title="${event.title}"></div>
                    `;
                });

                if (dayEvents.length > 3) {
                    html += `<div class="event-more">+${dayEvents.length - 3}</div>`;
                }

                html += `</div></div>`;
                current.setDate(current.getDate() + 1);
            }
        }

        html += `</div></div>`;
        return html;
    },

    // Render week view
    renderWeekView() {
        const startOfWeek = this.getStartOfWeek(this.currentDate);
        const timeSlots = this.generateTimeSlots();

        let html = `
            <div class="calendar-grid week-view">
                <div class="time-column">
                    <div class="time-header"></div>
        `;

        timeSlots.forEach(time => {
            html += `<div class="time-slot-label">${time}</div>`;
        });

        html += `</div>`;

        // Day columns
        for (let i = 0; i < 7; i++) {
            const date = new Date(startOfWeek);
            date.setDate(startOfWeek.getDate() + i);
            const isToday = this.isToday(date);

            html += `
                <div class="day-column ${isToday ? 'today' : ''}">
                    <div class="day-header">
                        <div class="day-name">${this.config.dayNamesShort[date.getDay()]}</div>
                        <div class="day-number">${date.getDate()}</div>
                    </div>
            `;

            timeSlots.forEach((time, index) => {
                const slotTime = this.timeSlotToDate(date, time);
                const event = this.getEventForTimeSlot(slotTime);

                html += `
                    <div class="time-slot ${event ? 'has-event' : ''}"
                         data-date="${date.toISOString()}"
                         data-time="${time}">
                        ${event ? `
                            <div class="event-block" style="background-color: ${event.color}">
                                <div class="event-title">${event.title}</div>
                            </div>
                        ` : ''}
                    </div>
                `;
            });

            html += `</div>`;
        }

        html += `</div>`;
        return html;
    },

    // Render day view
    renderDayView() {
        const date = new Date(this.currentDate);
        const timeSlots = this.generateTimeSlots();
        const isToday = this.isToday(date);

        let html = `
            <div class="calendar-grid day-view">
                <div class="day-header ${isToday ? 'today' : ''}">
                    <h3>${date.getDate()}日 (${this.config.dayNames[date.getDay()]})</h3>
                </div>
                <div class="time-slots">
        `;

        timeSlots.forEach(time => {
            const slotTime = this.timeSlotToDate(date, time);
            const event = this.getEventForTimeSlot(slotTime);

            html += `
                <div class="time-slot-row ${event ? 'has-event' : ''}"
                     data-date="${date.toISOString()}"
                     data-time="${time}">
                    <div class="time-label">${time}</div>
                    <div class="slot-content">
                        ${event ? `
                            <div class="event-detail" style="border-left-color: ${event.color}">
                                <div class="event-title">${event.title}</div>
                                <div class="event-info">
                                    <span class="customer">${event.customer}</span> |
                                    <span class="service">${event.service}</span> |
                                    <span class="staff">${event.staff}</span>
                                </div>
                            </div>
                        ` : `
                            <button class="btn-add-appointment" data-time="${time}">
                                + 予約を追加
                            </button>
                        `}
                    </div>
                </div>
            `;
        });

        html += `</div></div>`;
        return html;
    },

    // Update calendar header
    updateCalendarHeader() {
        const headerTitle = document.querySelector('.calendar-title');
        if (!headerTitle) return;

        let title = '';
        switch (this.view) {
            case 'month':
                title = `${this.currentDate.getFullYear()}年 ${this.config.monthNames[this.currentDate.getMonth()]}`;
                break;
            case 'week':
                const startOfWeek = this.getStartOfWeek(this.currentDate);
                const endOfWeek = new Date(startOfWeek);
                endOfWeek.setDate(startOfWeek.getDate() + 6);
                title = `${startOfWeek.getMonth() + 1}/${startOfWeek.getDate()} - ${endOfWeek.getMonth() + 1}/${endOfWeek.getDate()}`;
                break;
            case 'day':
                title = `${this.currentDate.getFullYear()}年${this.currentDate.getMonth() + 1}月${this.currentDate.getDate()}日`;
                break;
        }

        headerTitle.textContent = title;
    },

    // Navigation methods
    navigatePrevious() {
        switch (this.view) {
            case 'month':
                this.currentDate.setMonth(this.currentDate.getMonth() - 1);
                break;
            case 'week':
                this.currentDate.setDate(this.currentDate.getDate() - 7);
                break;
            case 'day':
                this.currentDate.setDate(this.currentDate.getDate() - 1);
                break;
        }
        this.renderCalendar();
    },

    navigateNext() {
        switch (this.view) {
            case 'month':
                this.currentDate.setMonth(this.currentDate.getMonth() + 1);
                break;
            case 'week':
                this.currentDate.setDate(this.currentDate.getDate() + 7);
                break;
            case 'day':
                this.currentDate.setDate(this.currentDate.getDate() + 1);
                break;
        }
        this.renderCalendar();
    },

    goToToday() {
        this.currentDate = new Date();
        this.selectedDate = new Date();
        this.renderCalendar();
    },

    changeView(newView) {
        this.view = newView;

        // Update active view button
        document.querySelectorAll('.calendar-view-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-view="${newView}"]`)?.classList.add('active');

        this.renderCalendar();
    },

    // Date selection
    selectDate(date) {
        this.selectedDate = new Date(date);
        this.renderCalendar();
    },

    // Time slot management
    setupTimeSlots() {
        // This would typically integrate with the backend
        console.log('Time slots initialized');
    },

    generateTimeSlots() {
        const slots = [];
        const { start, end, interval } = this.config.timeSlots;

        for (let hour = start; hour < end; hour++) {
            for (let minute = 0; minute < 60; minute += interval) {
                const timeStr = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
                slots.push(timeStr);
            }
        }

        return slots;
    },

    timeSlotToDate(date, timeStr) {
        const [hours, minutes] = timeStr.split(':').map(Number);
        const result = new Date(date);
        result.setHours(hours, minutes, 0, 0);
        return result;
    },

    handleTimeSlotClick(element) {
        const date = element.getAttribute('data-date');
        const time = element.getAttribute('data-time');

        if (element.classList.contains('has-event')) {
            // Show event details
            this.showEventDetails(date, time);
        } else {
            // Show booking form
            this.showBookingForm(date, time);
        }
    },

    // Event management
    getEventsForDate(date) {
        return this.events.filter(event => 
            this.isSameDay(event.start, date)
        );
    },

    getEventForTimeSlot(slotTime) {
        return this.events.find(event => 
            slotTime >= event.start && slotTime < event.end
        );
    },

    showEventDetails(date, time) {
        const slotTime = this.timeSlotToDate(new Date(date), time);
        const event = this.getEventForTimeSlot(slotTime);

        if (event) {
            const modalHTML = `
                <div class="modal-overlay">
                    <div class="modal event-detail-modal">
                        <div class="modal-header">
                            <h3>予約詳細</h3>
                            <button class="modal-close">&times;</button>
                        </div>
                        <div class="modal-body">
                            <div class="event-info-grid">
                                <div class="info-item">
                                    <label>お客様:</label>
                                    <span>${event.customer}</span>
                                </div>
                                <div class="info-item">
                                    <label>サービス:</label>
                                    <span>${event.service}</span>
                                </div>
                                <div class="info-item">
                                    <label>担当スタッフ:</label>
                                    <span>${event.staff}</span>
                                </div>
                                <div class="info-item">
                                    <label>時間:</label>
                                    <span>${this.formatTime(event.start)} - ${this.formatTime(event.end)}</span>
                                </div>
                                <div class="info-item">
                                    <label>ステータス:</label>
                                    <span class="badge badge-${event.status === 'confirmed' ? 'success' : 'warning'}">
                                        ${event.status === 'confirmed' ? '確定' : '仮予約'}
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary modal-close">閉じる</button>
                            <button class="btn btn-primary" data-action="edit-event" data-id="${event.id}">編集</button>
                        </div>
                    </div>
                </div>
            `;

            document.body.insertAdjacentHTML('beforeend', modalHTML);
            this.setupModalEvents();
        }
    },

    showBookingForm(date, time) {
        const modalHTML = `
            <div class="modal-overlay">
                <div class="modal booking-form-modal">
                    <div class="modal-header">
                        <h3>新規予約</h3>
                        <button class="modal-close">&times;</button>
                    </div>
                    <div class="modal-body">
                        <form class="booking-form">
                            <div class="form-group">
                                <label class="form-label">お客様名</label>
                                <input type="text" class="form-input" name="customer" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">電話番号</label>
                                <input type="tel" class="form-input" name="phone" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">サービス</label>
                                <select class="form-select" name="service" required>
                                    <option value="">選択してください</option>
                                    <option value="aroma">アロマトリートメント</option>
                                    <option value="thai">タイ古式マッサージ</option>
                                    <option value="deep">ディープティシューマッサージ</option>
                                    <option value="reflexology">リフレクソロジー</option>
                                    <option value="head">ヘッドマッサージ</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">担当スタッフ</label>
                                <select class="form-select" name="staff" required>
                                    <option value="">選択してください</option>
                                    <option value="sato">佐藤美香</option>
                                    <option value="suzuki">鈴木恵美</option>
                                    <option value="tanaka">田中由美</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">日時</label>
                                <input type="text" class="form-input" value="${new Date(date).toLocaleDateString('ja-JP')} ${time}" readonly>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary modal-close">キャンセル</button>
                        <button class="btn btn-primary" type="submit">予約を作成</button>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);
        this.setupModalEvents();
    },

    setupModalEvents() {
        const modal = document.querySelector('.modal-overlay:last-child');
        if (!modal) return;

        // Close modal events
        modal.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', () => modal.remove());
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });

        // Form submission
        const form = modal.querySelector('form');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleBookingSubmit(form);
                modal.remove();
            });
        }
    },

    handleBookingSubmit(form) {
        const formData = new FormData(form);
        console.log('Booking submitted:', Object.fromEntries(formData));

        // Show success notification
        if (window.CaskanApp) {
            window.CaskanApp.showNotification('予約が正常に作成されました', 'success');
        }

        // Refresh calendar
        this.renderCalendar();
    },

    // Keyboard navigation
    handleKeyboardNavigation(e) {
        switch (e.key) {
            case 'ArrowLeft':
                e.preventDefault();
                this.navigatePrevious();
                break;
            case 'ArrowRight':
                e.preventDefault();
                this.navigateNext();
                break;
            case 'Home':
                e.preventDefault();
                this.goToToday();
                break;
            case 'm':
                if (e.ctrlKey || e.metaKey) {
                    e.preventDefault();
                    this.changeView('month');
                }
                break;
            case 'w':
                if (e.ctrlKey || e.metaKey) {
                    e.preventDefault();
                    this.changeView('week');
                }
                break;
            case 'd':
                if (e.ctrlKey || e.metaKey) {
                    e.preventDefault();
                    this.changeView('day');
                }
                break;
        }
    },

    // Utility methods
    isToday(date) {
        const today = new Date();
        return this.isSameDay(date, today);
    },

    isSameDay(date1, date2) {
        return date1.getDate() === date2.getDate() &&
               date1.getMonth() === date2.getMonth() &&
               date1.getFullYear() === date2.getFullYear();
    },

    getStartOfWeek(date) {
        const result = new Date(date);
        const day = result.getDay();
        const diff = result.getDate() - day;
        result.setDate(diff);
        return result;
    },

    formatTime(date) {
        return date.toLocaleTimeString('ja-JP', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }
};

// Initialize calendar when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    CaskanCalendar.init();
});

// Export for global access
window.CaskanCalendar = CaskanCalendar;
