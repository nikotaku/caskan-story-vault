
/**
 * Caskan Reservation Management System - Charts JavaScript
 * Handles Chart.js integration and data visualization
 */

// Chart configurations and data management
const CaskanCharts = {
    // Chart instances storage
    charts: {},

    // Color scheme for charts
    colors: {
        primary: '#1e3a8a',
        secondary: '#2563eb',
        success: '#10b981',
        warning: '#f59e0b',
        danger: '#ef4444',
        info: '#3b82f6',
        light: '#f8fafc',
        dark: '#1f2937'
    },

    // Initialize all charts
    init() {
        this.initDashboardCharts();
        this.initReportCharts();

        // Update charts on window resize
        window.addEventListener('resize', () => {
            this.resizeCharts();
        });
    },

    // Initialize dashboard charts
    initDashboardCharts() {
        this.createRevenueChart();
        this.createReservationStatusChart();
        this.createServicePopularityChart();
    },

    // Initialize report page charts
    initReportCharts() {
        this.createMonthlyRevenueChart();
        this.createCustomerGrowthChart();
        this.createServiceAnalyticsChart();
        this.createHourlyBookingChart();
    },

    // Create revenue trend chart for dashboard
    createRevenueChart() {
        const ctx = document.getElementById('revenueChart');
        if (!ctx) return;

        const data = {
            labels: ['1月', '2月', '3月', '4月', '5月', '6月', '7月'],
            datasets: [{
                label: '売上 (万円)',
                data: [120, 135, 158, 142, 167, 189, 203],
                borderColor: this.colors.primary,
                backgroundColor: this.colors.primary + '20',
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        };

        this.charts.revenue = new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: this.colors.primary,
                        borderWidth: 1
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    },
                    y: {
                        grid: {
                            color: '#f1f5f9'
                        },
                        ticks: {
                            color: '#6b7280',
                            callback: function(value) {
                                return value + '万円';
                            }
                        }
                    }
                }
            }
        });
    },

    // Create reservation status pie chart
    createReservationStatusChart() {
        const ctx = document.getElementById('reservationStatusChart');
        if (!ctx) return;

        const data = {
            labels: ['確定', '仮予約', 'キャンセル'],
            datasets: [{
                data: [65, 25, 10],
                backgroundColor: [
                    this.colors.success,
                    this.colors.warning,
                    this.colors.danger
                ],
                borderWidth: 0
            }]
        };

        this.charts.reservationStatus = new Chart(ctx, {
            type: 'doughnut',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true,
                            color: '#374151'
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.parsed + '%';
                            }
                        }
                    }
                },
                cutout: '60%'
            }
        });
    },

    // Create service popularity bar chart
    createServicePopularityChart() {
        const ctx = document.getElementById('servicePopularityChart');
        if (!ctx) return;

        const data = {
            labels: ['アロマトリートメント', 'タイ古式マッサージ', 'ディープティシュー', 'リフレクソロジー', 'ヘッドマッサージ'],
            datasets: [{
                label: '予約数',
                data: [45, 38, 32, 28, 22],
                backgroundColor: [
                    this.colors.primary,
                    this.colors.secondary,
                    this.colors.success,
                    this.colors.warning,
                    this.colors.info
                ],
                borderRadius: 8,
                borderSkipped: false
            }]
        };

        this.charts.servicePopularity = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: '#f1f5f9'
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    },
                    y: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#6b7280',
                            maxRotation: 0
                        }
                    }
                }
            }
        });
    },

    // Create monthly revenue chart for reports
    createMonthlyRevenueChart() {
        const ctx = document.getElementById('monthlyRevenueChart');
        if (!ctx) return;

        const data = {
            labels: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
            datasets: [
                {
                    label: '2024年',
                    data: [120, 135, 158, 142, 167, 189, 203, 195, 178, 165, 152, 168],
                    borderColor: this.colors.primary,
                    backgroundColor: this.colors.primary + '20',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                },
                {
                    label: '2023年',
                    data: [98, 112, 125, 118, 134, 145, 156, 148, 141, 138, 129, 143],
                    borderColor: this.colors.secondary,
                    backgroundColor: this.colors.secondary + '20',
                    borderWidth: 2,
                    fill: false,
                    borderDash: [5, 5]
                }
            ]
        };

        this.charts.monthlyRevenue = new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: '#374151',
                            usePointStyle: true,
                            padding: 20
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: '#f1f5f9'
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    },
                    y: {
                        grid: {
                            color: '#f1f5f9'
                        },
                        ticks: {
                            color: '#6b7280',
                            callback: function(value) {
                                return value + '万円';
                            }
                        }
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        });
    },

    // Create customer growth chart
    createCustomerGrowthChart() {
        const ctx = document.getElementById('customerGrowthChart');
        if (!ctx) return;

        const data = {
            labels: ['1月', '2月', '3月', '4月', '5月', '6月'],
            datasets: [
                {
                    label: '新規顧客',
                    data: [23, 28, 35, 42, 38, 45],
                    backgroundColor: this.colors.success,
                    borderRadius: 4
                },
                {
                    label: 'リピーター',
                    data: [87, 94, 102, 98, 105, 112],
                    backgroundColor: this.colors.primary,
                    borderRadius: 4
                }
            ]
        };

        this.charts.customerGrowth = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: '#374151',
                            usePointStyle: true
                        }
                    }
                },
                scales: {
                    x: {
                        stacked: true,
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    },
                    y: {
                        stacked: true,
                        grid: {
                            color: '#f1f5f9'
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    }
                }
            }
        });
    },

    // Create service analytics radar chart
    createServiceAnalyticsChart() {
        const ctx = document.getElementById('serviceAnalyticsChart');
        if (!ctx) return;

        const data = {
            labels: ['アロマ', 'タイ古式', 'ディープ', 'リフレ', 'ヘッド', 'ストレッチ'],
            datasets: [{
                label: '人気度',
                data: [85, 72, 68, 62, 58, 45],
                backgroundColor: this.colors.primary + '30',
                borderColor: this.colors.primary,
                borderWidth: 2,
                pointBackgroundColor: this.colors.primary,
                pointBorderColor: '#ffffff',
                pointHoverBackgroundColor: '#ffffff',
                pointHoverBorderColor: this.colors.primary
            }]
        };

        this.charts.serviceAnalytics = new Chart(ctx, {
            type: 'radar',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100,
                        grid: {
                            color: '#f1f5f9'
                        },
                        angleLines: {
                            color: '#e2e8f0'
                        },
                        ticks: {
                            color: '#6b7280',
                            stepSize: 20
                        },
                        pointLabels: {
                            color: '#374151',
                            font: {
                                size: 12
                            }
                        }
                    }
                }
            }
        });
    },

    // Create hourly booking pattern chart
    createHourlyBookingChart() {
        const ctx = document.getElementById('hourlyBookingChart');
        if (!ctx) return;

        const hours = ['9時', '10時', '11時', '12時', '13時', '14時', '15時', '16時', '17時', '18時', '19時', '20時', '21時'];
        const bookingData = [2, 5, 8, 12, 15, 18, 22, 25, 20, 16, 12, 8, 4];

        const data = {
            labels: hours,
            datasets: [{
                label: '予約数',
                data: bookingData,
                backgroundColor: bookingData.map(value => {
                    if (value >= 20) return this.colors.danger;
                    if (value >= 15) return this.colors.warning;
                    if (value >= 10) return this.colors.success;
                    return this.colors.info;
                }),
                borderRadius: 6,
                borderSkipped: false
            }]
        };

        this.charts.hourlyBooking = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '予約数: ' + context.parsed.y + '件';
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#6b7280',
                            maxRotation: 45
                        }
                    },
                    y: {
                        grid: {
                            color: '#f1f5f9'
                        },
                        ticks: {
                            color: '#6b7280',
                            stepSize: 5
                        }
                    }
                }
            }
        });
    },

    // Update chart data
    updateChartData(chartName, newData) {
        const chart = this.charts[chartName];
        if (!chart) return;

        chart.data = newData;
        chart.update('active');
    },

    // Resize all charts
    resizeCharts() {
        Object.values(this.charts).forEach(chart => {
            chart.resize();
        });
    },

    // Destroy all charts
    destroyCharts() {
        Object.values(this.charts).forEach(chart => {
            chart.destroy();
        });
        this.charts = {};
    },

    // Generate sample data for development
    generateSampleData(type, count = 12) {
        const data = [];
        const baseValue = type === 'revenue' ? 150 : type === 'customers' ? 50 : 20;

        for (let i = 0; i < count; i++) {
            const variation = (Math.random() - 0.5) * 0.3;
            const trend = Math.sin(i / count * Math.PI) * 0.2;
            data.push(Math.round(baseValue * (1 + variation + trend)));
        }

        return data;
    },

    // Export chart as image
    exportChart(chartName, filename) {
        const chart = this.charts[chartName];
        if (!chart) return;

        const url = chart.toBase64Image();
        const link = document.createElement('a');
        link.href = url;
        link.download = filename || `${chartName}_chart.png`;
        link.click();
    },

    // Utility function to get chart colors
    getChartColors(count, opacity = 1) {
        const baseColors = [
            this.colors.primary,
            this.colors.secondary,
            this.colors.success,
            this.colors.warning,
            this.colors.danger,
            this.colors.info
        ];

        const colors = [];
        for (let i = 0; i < count; i++) {
            const color = baseColors[i % baseColors.length];
            colors.push(opacity < 1 ? color + Math.round(opacity * 255).toString(16).padStart(2, '0') : color);
        }

        return colors;
    }
};

// Initialize charts when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    // Wait a bit for Chart.js to be loaded
    setTimeout(() => {
        if (typeof Chart !== 'undefined') {
            CaskanCharts.init();
        }
    }, 100);
});

// Export for global access
window.CaskanCharts = CaskanCharts;
